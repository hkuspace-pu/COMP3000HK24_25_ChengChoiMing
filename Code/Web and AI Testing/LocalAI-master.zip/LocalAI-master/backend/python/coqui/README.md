# Creating a separate environment for ttsbark project

```
make coqui
```

# Testing the gRPC server

```
make test
```