# Creating a separate environment for the reranker project

```
make reranker
```