//go:build !debug
// +build !debug

package main

func assert(cond bool, msg string) {
}
