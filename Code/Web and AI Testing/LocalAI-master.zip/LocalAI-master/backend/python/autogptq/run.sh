#!/bin/bash
source $(dirname $0)/../common/libbackend.sh

startBackend $@