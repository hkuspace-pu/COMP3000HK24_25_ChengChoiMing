#!/bin/bash
LIMIT_TARGETS="cublas"

source $(dirname $0)/../common/libbackend.sh

startBackend $@