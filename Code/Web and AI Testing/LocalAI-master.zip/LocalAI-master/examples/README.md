# LocalAI Examples

LocalAI examples were moved to a dedicated repository: https://github.com/mudler/LocalAI-examples
